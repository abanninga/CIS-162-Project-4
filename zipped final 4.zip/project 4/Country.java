import java.text.DecimalFormat;
/**
 * This class stores facts about a country
 *
 * @author Alaine Banninga
 * @version April 3rd, 2018
 */
public class Country implements Comparable 
{
    private String name;
    private String continent;
    private int area;
    private double population;
    private double gdp;
    private String capital;

    /**
     * Constructor for Country that sets name to "Default"
     */
    public Country(){
        name = "Default";
    }

    /**
     * Constructor for Country that initializes all instance variables
     * to their corresponding parameters
     */
    public Country(String name, String continent, int area,
    double population, double gdp, String capital){
        this.name = name;
        this.continent = continent;
        this.area = area;
        this.population = population;
        this.gdp = gdp;
        this.capital = capital;
    }

    /**
     * Getter for name
     * 
     * @return Returns name of country
     */
    public String getName(){
        return name;
    }

    /**
     * Getter for continent
     * 
     * @return Returns country's continent
     */
    public String getContinent(){
        return continent;
    }

    /**
     * Getter for area
     * 
     * @return Returns area of country in square kilometers
     */
    public int getArea(){
        return area;
    }

    /**
     * Getter for population
     * 
     * @return Returns country's population
     */
    public double getPopulation(){
        return population;
    }

    /**
     * Getter for gdp
     * 
     * @return Returns country's GDP
     */
    public double getGdp(){
        return gdp;
    }

    /**
     * Getter for capital
     * 
     * @return Returns the country's capital
     */
    public String getCapital(){
        return capital;
    }

    /**
     * Setter for name
     * 
     * @param Input for name
     */
    public void setName(String name){
        this.name = name;
    }

    /**
     * Setter for continent
     * 
     * @param Input for continent
     */
    public void setContinent(String continent){
        this.continent = continent;
    }

    /**
     * Setter for area
     * 
     * @param Input for area
     */
    public void setArea(int area){
        this.area = area;
    }

    /**
     * Setter for population
     * 
     * @param Input for population
     */
    public void setPopulation(double population){
        this.population = population;
    }

    /**
     * Setter for GDP
     * 
     * @param Input for GDP
     */
    public void setGdp(double gdp){
        this.gdp = gdp;
    }

    /**
     * Setter for capital
     * 
     * @param Input for capital
     */
    public void setCapital(String capital){
        this.capital = capital;
    }

    /**
     * toString method for returning formatted version of the country
     * 
     * @return Returns a formatted string of the country
     */
    public String toString(){
        DecimalFormat fmt = new DecimalFormat("#.##");
        DecimalFormat fmt2 = new DecimalFormat("#");
        return name + ", Capital: " + capital + ", GDP: " + fmt.format(gdp/1000000000) + 
        " billion, Per Capita GDP: " + fmt2.format(gdp/population) + "\n";
    }

    /**
     * Main method for testing methods of Country class
     */
    public static void main(String[]args){
        Country c = new Country("USA", "North America", 150000, 1000000000,
                1000000000, "DC");
        System.out.println(c.toString());
        c.setPopulation(1500000000);
        c.setCapital("Ottawa");
        c.setArea(200000);
        c.setGdp(2000000000);
        c.setContinent("America");
        c.setName("Canada");
        System.out.println(c.toString());
    }

    /**
     * Allows two Country objects to be compared with respect to gdp
     */
    public int compareTo(Object other){
        Country c = (Country) other;
        return (int)(c.gdp - gdp);
    }
}
