import java.util.ArrayList;
/**
 * Write a description of class CountryTest here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CountryTest
{
    public static void main(String args[]){
        CountryDatabase db = new CountryDatabase();

        // read the countries of the world file
        db.readCountriesData("Countries.csv");

        System.out.println("****Begin test***");

        // check number of records
        if(db.countAllCountries() != 195){
            System.out.println("Error: Number of countries should be 195");
        }

        // Testing population - countries with a population > 900 million
        ArrayList <Country> tempList = db.searchCountriesWithPopulation(900000000);

        if(tempList.size() != 2){
            System.out.println("Error: it should be two countries with a " + 
                "population greater than 900 million");
        }
        
        // getting all countries
        System.out.println(db.getAllCountries());
        
        // highest GDP
        System.out.println(db.highestGdp("North America"));
        
        // smallestArea
        System.out.println(db.smallestArea("Asia"));
        
        // search for capital
        System.out.println(db.searchForCapital("Canada"));
        
        //find country details
        System.out.println(db.findCountryDetails("Malawi"));
        
        // search countries in continent
        System.out.println(db.searchCountriesInContinent("North America"));
        
        //search countries with population
        System.out.println(db.searchCountriesWithPopulation(900000000));
        
        // top ten gdp countries
        System.out.println(db.topTenGdpCountries("Asia"));
        
        System.out.println("*** Test complete***");
    }
}
