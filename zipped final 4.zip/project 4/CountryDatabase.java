import java.util.ArrayList;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.util.Collections;
/**
 * Write a description of class CountryDatabase here.
 *
 * @author Alaine Banninga
 * @version April 3rd, 2018
 */
public class CountryDatabase
{
    private ArrayList<Country> countries;

    /**
     * Constructor for CountryDatabase
     */
    public CountryDatabase(){
        countries = new ArrayList<Country>();
    }

    /**
     * Reads data from file and adds entries to ArrayList countries
     * 
     * @param The file we are reading data from: countries.csv
     */
    public void readCountriesData(String filename){
        // Read the full set of data from a text file
        try{ 

            // open the text file and use a Scanner to read the text
            FileInputStream fileByteStream = new FileInputStream(filename);
            Scanner scnr = new Scanner(fileByteStream);
            scnr.useDelimiter("[,\r\n]+");

            // keep reading as long as there is more data
            while(scnr.hasNext()) {

                // reading the fields from the record one at the time
                String name = scnr.next();
                String continent = scnr.next();

                // FIX ME: capture the area, population, GDP, and capital
                int area = scnr.nextInt();
                double population = scnr.nextDouble();
                double gdp = scnr.nextDouble();
                String capital = scnr.next();

                // instantiate a new Country with the data that was read
                Country entry = new Country(name, continent, area, population,
                        gdp, capital);

                // FIX ME: Add the Country created on previous instruction
                // to the ArrayList
                countries.add(entry);
            }
            fileByteStream.close();
        }
        catch(IOException e) {
            System.out.println("Failed to read the data file: " + filename);
        }
    }

    /**
     * Gives the number of items in countries
     * 
     * @return Returns number of items in countries
     */
    public int countAllCountries(){
        return countries.size();
    }

    /**
     * Returns the list of entries in countries
     * 
     * @return countries ArrayList
     */
    public ArrayList<Country> getAllCountries(){
        return countries;
    }

    /**
     * Finds the country with the highest GDP for specified continent
     * 
     * @param whichever continent the user is searching
     * @return Returns the country from that continent with highest GDP
     */
    public Country highestGdp(String continent){
        double largest = 0;
        Country largestCountry = new Country();
        for(Country c : countries){
            if(c.getContinent().equalsIgnoreCase(continent) && 
            c.getGdp() > largest){
                largestCountry = c;
                largest = c.getGdp();
            }
        }
        return largestCountry;
    }

    /**
     * Finds the country with smallest area per input continent
     * 
     * @param whichever continent the user is searching
     * @return Returns country with smallest area
     */
    public Country smallestArea(String continent){
        int smallest = 1000000000;
        Country smallestCountry = new Country();
        for(Country c : countries){
            if(c.getContinent().equalsIgnoreCase(continent) && 
            c.getArea() < smallest){
                smallestCountry = c;
                smallest = c.getArea();
            }
        }
        return smallestCountry;
    }

    /**
     * Finds the capital of the country entered as a parameter
     * 
     * @param The country whose capital the user wants to know
     * @return Returns the capital of the country
     */
    public String searchForCapital(String countryName){
        for(Country c : countries)
            if(c.getName().equalsIgnoreCase(countryName))
                return c.getCapital();
        return null;
    }

    /**
     * Searches for country name
     * 
     * @param countryName = name of country you are searching
     * @return Returns the country if found, null otherwise
     */
    public Country findCountryDetails(String countryName){
        for(Country c : countries)
            if(c.getName().equalsIgnoreCase(countryName))
                return c;
        return null;
    }

    /**
     * Returns a list of all countries in continent parameter
     * 
     * @param continent of which the user wants to know all of the countries
     * @return Returns an ArrayList of countries belonging to said continent
     */
    public ArrayList<Country> searchCountriesInContinent(String continent){
        ArrayList<Country> list = new ArrayList<Country>();
        for(Country c : countries)
            if(c.getContinent().equalsIgnoreCase(continent))
                list.add(c);
        Collections.sort(list);
        return list;
    }

    /**
     * Returns a list of countries with population at least as large
     * as the parameter
     * 
     * @param the baseline population
     * @returns All countries with population larger than parameter
     */
    public ArrayList<Country> searchCountriesWithPopulation(double population){
        ArrayList list = new ArrayList<Country>();
        for(Country c : countries)
            if(c.getPopulation() > population)
                list.add(c);
        return list;
    }

    /**
     * Gives the countries with the top ten GDP for their continent
     * 
     * @param the continent the user is searching
     * @return Returns the top ten list
     */
    public ArrayList<Country> topTenGdpCountries(String continent){
        ArrayList<Country> list = searchCountriesInContinent(continent);
        ArrayList<Country> list2 = new ArrayList<Country>();
        for(int i = 0; i < 10; i++)
            list2.add(list.get(i));
        return list2;    
    }
}
